# PyAnna
Creating an artificial neural network for character recognition

Addidtional libraries

pygame - https://www.pygame.org

Keys / Help

c = clear drawing field

0,1,2,3,4,5,6,7,8,9 = add content from drawing field to training-set as DIGIT [digit clicked] and clear drawing field

To Do

- implement minimal class for artifical neural network - check
- test this class for the logical XOR - 100%
- make user able to draw single digit - 100%
- let the network learn the single digit - 100%
- save the drawn single digit to file as a lossless png - 100%
- save the network weights in a file, to not lose the learning progress - 100%
- let the network learn digits from saved files - 100%%
- create KPIs to approximate network precision - 10%
- improve backpropagation algorythm - 100%
- create documentation - 100%
